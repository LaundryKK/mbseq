#ifndef	_PROGLOCK_H
#define	_PROGLOCK_H

/* $Id: proglock.h,v 1.1 2003/08/03 14:08:08 mbroek Exp $ */

int lockprogram(char *);
void ulockprogram(char*);

#endif
