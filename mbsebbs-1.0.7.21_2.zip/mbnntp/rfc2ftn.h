#ifndef	_RFC2FTN_H
#define	_RFC2FTN_H

/* $Id: rfc2ftn.h,v 1.2 2004/06/20 14:38:12 mbse Exp $ */

#ifndef	USE_NEWSGATE

int rfc2ftn(FILE *fp);

#endif

#endif
