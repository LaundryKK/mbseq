#ifndef _MBFIDO_H
#define _MBFIDO_H

/* $Id: mbfido.h,v 1.2 2005/08/10 18:57:22 mbse Exp $ */

void	Help(void);
void	ProgName(void);
void	die(int);
int	TossPkts(void);
int	TossMail(void);
int	toss(char *);

#endif


