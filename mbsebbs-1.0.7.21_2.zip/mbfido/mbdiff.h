#ifndef _MBFIFF_H
#define	_MBDIFF_H


void	Help(void);
int	apply(char *, char *, char *);
char	*unpacker(char *);
int	getarchiver(char *);


#endif

