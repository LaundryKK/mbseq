#ifndef	_FTNMSG_H
#define	_FTNMSG_H

/* $Id: msg.h,v 1.2 2004/07/23 21:24:09 mbse Exp $ */

int toss_msgs(void);

#endif
