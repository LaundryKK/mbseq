#ifndef _MBFCHECK_H
#define _MBFCHECK_H

/* $Id: mbfcheck.h,v 1.3 2005/10/11 20:49:47 mbse Exp $ */

void	Check(int);			/* Check file database		*/

#endif
