#ifndef _STORENET_H
#define _STORENET_H


int	storenet(faddr *, faddr *, time_t, int, char *, char *, char *, FILE *, char*);

#endif

