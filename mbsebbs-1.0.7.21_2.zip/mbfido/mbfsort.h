/* $Id: mbfsort.h,v 1.1 2003/11/08 15:30:04 mbroek Exp $ */

#ifndef _MBFSORT_H
#define _MBFSORT_H

void	SortFileBase(int);		/* Sort File Base	*/

#endif
