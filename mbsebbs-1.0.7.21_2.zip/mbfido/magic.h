#ifndef _MAGIC_H
#define	_MAGIC_H


int	GetMagicRec(int, int);
void	MagicResult(char *, ...);
int	Magic_MoveFile(void);
void	Magic_ExecCommand(void);
void	Magic_CopyFile(void);
void	Magic_UnpackFile(void);
void	Magic_Keepnum(void);
void	Magic_UpDateAlias(void);
void	Magic_AdoptFile(void);
int	Magic_DeleteFile(void);


#endif

