#ifndef	_RNEWS_H
#define	_RNEWS_H


#define MAX_FORKS	10
#define STDIN		0
#define STDOUT		1
#define STDERR		2
#define PIPE_READ	0
#define PIPE_WRITE	1
#define RNEWS_MAGIC1	'#'
#define RNEWS_MAGIC2	'!'
#define SMBUF      	256


void NewsUUCP(void);


#endif

