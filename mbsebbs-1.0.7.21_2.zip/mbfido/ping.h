#ifndef _PINGMGR_H
#define _PINGMGR_H


int  Ping(faddr *, faddr *, FILE *, int);


#endif

