#ifndef	_HATCH_H
#define	_HATCH_H


void Hatch(void);


#endif

