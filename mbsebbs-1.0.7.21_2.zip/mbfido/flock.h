/* flock.h */

#ifndef _FLOCK_H
#define _FLOCK_H

int	f_lock(char *);
void	funlock(int);

#endif

