#ifndef _MAKESTAT_H
#define _MAKESTAT_H


void MakeStat(void);


#endif

