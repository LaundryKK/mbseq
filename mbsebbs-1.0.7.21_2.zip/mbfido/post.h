#ifndef _POST_H
#define _POST_H

/* $Id: post.h,v 1.3 2005/10/11 20:49:47 mbse Exp $ */

int Post(char *, int, char *, char *, char *);	/* Post a Message */


#endif
