/* $Id: mbfadopt.h,v 1.1 2001/11/18 23:19:08 mbroek Exp $ */

#ifndef _MBFADOPT_H_
#define _MBFADOPT_H

void	AdoptFile(int, char *, char *);

#endif
