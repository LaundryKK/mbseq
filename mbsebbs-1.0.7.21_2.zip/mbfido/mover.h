/* $Id: mover.h,v 1.2 2001/12/09 15:20:51 mbroek Exp $ */

#ifndef	_MOVER_H
#define	_MOVER_H


void mover(char *);
void MoveBad(void);


#endif

