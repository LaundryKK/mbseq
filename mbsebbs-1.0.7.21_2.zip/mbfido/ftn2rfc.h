#ifndef _FTN2RFC_H
#define _FTN2RFC_H


int	ftn2rfc(faddr *, faddr *, char *, char *, time_t, int, FILE *);

#endif

