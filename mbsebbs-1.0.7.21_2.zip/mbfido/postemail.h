#ifndef _POSTEMAIL_H
#define _POSTEMAIL_H


int	postemail(FILE *, char *, char *);

#endif

