#ifndef	_QUEUE_H
#define	_QUEUE_H

/* $Id: queue.h,v 1.3 2004/05/24 18:30:09 mbse Exp $ */


char *Basename(char *);
void flush_queue(void);


#endif
