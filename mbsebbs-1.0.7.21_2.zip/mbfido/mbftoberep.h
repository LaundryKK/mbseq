/* $Id: mbftoberep.h,v 1.1 2001/11/25 16:38:06 mbroek Exp $ */

#ifndef _MBFTOBEREP_H
#define _MBFTOBEREP_H

void	ToBeRep(void);		/* Show toberep database */

#endif
