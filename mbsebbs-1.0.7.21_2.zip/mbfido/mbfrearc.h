#ifndef _MBFREARC_H
#define _MBFREARC_H

/* $Id: mbfrearc.h,v 1.1 2004/03/08 20:51:05 mbroek Exp $ */

void ReArc(int, char *);

#endif
