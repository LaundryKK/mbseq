#ifndef	_ADDBBS_H
#define	_ADDBBS_H

/* $Id: addbbs.h,v 1.2 2004/07/16 20:21:23 mbse Exp $ */


int Add_BBS(qualify **);

#endif
