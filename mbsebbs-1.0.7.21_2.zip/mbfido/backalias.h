#ifndef	_BACKALIAS_H
#define	_BACKALIAS_H

char *backalias(faddr *);
void readalias(char *);

#endif

