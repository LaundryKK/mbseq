/* $Id: mbfkill.h,v 1.1 2001/11/18 23:19:08 mbroek Exp $ */

#ifndef _MBFKILL_H
#define	_MBFKILL_H

void Kill(void);

#endif
