#ifndef _MAKETAGS_H
#define _MAKETAGS_H


void MakeTags(void);


#endif

