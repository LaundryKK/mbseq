#ifndef	_TRACKER_H
#define	_TRACKER_H

/* $Id: tracker.h,v 1.3 2002/07/17 20:26:35 mbroek Exp $ */

int	TrackMail(fidoaddr, fidoaddr *);
void	TestTracker(faddr *);

#endif
