#ifndef _POSTECHO_H
#define _POSTECHO_H

/* $Id: postecho.h,v 1.3 2004/08/12 12:50:53 mbse Exp $ */


int	postecho(faddr *, faddr *, faddr *, char *, char *, time_t, int, int, FILE *, int, int);


#endif

