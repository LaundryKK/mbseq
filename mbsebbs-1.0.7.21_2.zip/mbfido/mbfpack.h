/* $Id: mbfpack.h,v 1.2 2003/11/08 15:30:04 mbroek Exp $ */

#ifndef _MBFPACK_H
#define _MBFPACK_H

void	PackFileBase(void);		/* Pack / Compress File Base	*/

#endif
