#ifndef _BOUNCEMGR_H
#define _BOUNCEMGR_H


int  Bounce(faddr *, faddr *, FILE *, char *);


#endif

