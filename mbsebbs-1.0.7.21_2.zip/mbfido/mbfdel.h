/* $Id: mbfdel.h,v 1.1 2001/12/02 22:36:23 mbroek Exp $ */

#ifndef _MBFDELE_H
#define _MBFDELE_H

void Delete(int, int, char *);

#endif
