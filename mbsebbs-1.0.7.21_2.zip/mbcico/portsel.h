/* $Id: portsel.h,v 1.2 2002/03/03 21:23:55 mbroek Exp $ */

#ifndef	_PORTSEL_H
#define	_PORTSEL_H


int  load_port(char *);
int  load_modem(char *);


#endif
