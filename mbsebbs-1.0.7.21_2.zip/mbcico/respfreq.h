#ifndef	_RESPFREQ_H
#define	_RESPFREQ_H

file_list *respond_wazoo(void);
file_list *respond_bark(char *);
file_list *respfreq(char *, char *, char *);
file_list *resplist(char *, char *, char *);
file_list *respmagic(char *);

#endif

