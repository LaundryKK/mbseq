#ifndef	_XMSEND_H
#define	_XMSEND_H

int xmsend(char *, char *, int);
int xmsndfiles(file_list *);


#endif

