#ifndef	_RDOPTIONS_H
#define	_RDOPTIONS_H

void rdoptions(int);

#endif

