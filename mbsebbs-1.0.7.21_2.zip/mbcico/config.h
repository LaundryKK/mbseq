#ifndef _CONFIG_H
#define _CONFIG_H

/* $Id: config.h,v 1.3 2005/10/11 20:49:46 mbse Exp $ */

extern int  configtime;
extern int  maxfsize;
extern int  maxmsize;


extern char *name;
extern char *phone;
extern char *flags;
extern char *inbound;
extern char *myfqdn;
extern char *debugfile;
extern char *nonpacked;
extern char *magicname;
extern char *dosoutbound;
extern char *uxoutbound;

#endif
