#ifndef	_CHAT_H
#define	_CHAT_H

/* $Id: chat.h,v 1.2 2002/07/02 20:00:51 mbroek Exp $ */

char	*tranphone(char *);
int	chat(char *, int, int, char *);

#endif

