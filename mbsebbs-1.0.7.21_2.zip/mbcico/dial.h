#ifndef	_DIAL_H
#define	_DIAL_H

/* $Id: dial.h,v 1.2 2002/07/02 20:00:51 mbroek Exp $ */


int  dialphone(char *);
int  hangup(void);
void aftercall(void);

#endif
