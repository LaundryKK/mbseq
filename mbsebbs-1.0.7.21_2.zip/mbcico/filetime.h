#ifndef	_FILETIME_H
#define	_FILETIME_H

time_t	mtime2sl(time_t);
time_t	sl2mtime(time_t);
time_t	mtime2tl(time_t);
time_t	tl2mtime(time_t);


#endif

