#ifndef	_XMRECV_H
#define	_XMRECV_H

int xmrecv(char *);

#endif

