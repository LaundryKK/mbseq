#ifndef	_ATOUL_H
#define	_ATOUL_H

/* $Id: atoul.h,v 1.2 2005/10/11 20:49:46 mbse Exp $ */

unsigned int atoul(char *);

#endif

