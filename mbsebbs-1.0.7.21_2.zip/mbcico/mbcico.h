#ifndef	_MBCICO_H
#define	_MBCICO_H

/* $Id: mbcico.h,v 1.3 2003/11/30 14:36:53 mbroek Exp $ */


void usage(void);
void free_mem(void);
void die(int);

#endif
