#ifndef _OUTSTAT_H
#define	_OUTSTAT_H


int each(faddr *, char, int, char *);
int outstat(void);
int pollnode(faddr *, int);
int reset(faddr *);
int freq(faddr *, char *);


#endif

