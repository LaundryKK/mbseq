#ifndef	_TCP_H
#define	_TCP_H

int rxtcp(void);
int txtcp(void);


#endif

