#ifndef	_DIETIFNA_H
#define	_DIETIFNA_H

int rxdietifna(void);
int txdietifna(void);


#endif

