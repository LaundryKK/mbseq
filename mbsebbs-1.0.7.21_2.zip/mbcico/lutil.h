#ifndef LUTIL_H
#define LUTIL_H

/* $Id: lutil.h,v 1.4 2005/10/11 20:49:46 mbse Exp $ */

void		setmyname(char *);
char		*date(time_t);
int		IsZMH(void);
unsigned int	rnd(void);

#endif
