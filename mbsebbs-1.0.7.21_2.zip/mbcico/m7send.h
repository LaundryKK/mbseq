#ifndef	M7SEND_H
#define	M7SEND_H

int m7send(char *);

#endif

