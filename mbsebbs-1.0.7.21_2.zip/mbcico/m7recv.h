#ifndef	_M7RECV_H
#define	_M7RECV_H

int m7recv(char *);


#endif

