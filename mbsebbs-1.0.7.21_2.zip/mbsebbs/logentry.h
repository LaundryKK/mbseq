/* $Id: logentry.h,v 1.1 2001/11/12 21:42:17 mbroek Exp $ */

#ifndef _LOGENTRY_H
#define _LOGENTRY_H

void LogEntry(char *);			    /* Create log entry in logfile	*/


#endif
