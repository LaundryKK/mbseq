/* $Id: lastcallers.h,v 1.1 2001/11/12 21:42:17 mbroek Exp $ */

#ifndef _LASTCALLERS_H
#define _LASTCALLERS_H

void LastCallers(char *);

#endif
