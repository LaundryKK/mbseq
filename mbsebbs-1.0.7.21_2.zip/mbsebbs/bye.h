#ifndef _BYE_H
#define _BYE_H

void Quick_Bye(int);
void Good_Bye(int);

#endif

