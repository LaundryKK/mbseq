#ifndef _CHAT_H
#define _CHAT_H

/* $Id: chat.h,v 1.3 2003/04/01 21:41:40 mbroek Exp $ */

void Chat(char *, char *);	/* Chat Function */

#endif
